#include <stdio.h>
#include <string.h>
int main()
{
    int found;
    char ctrs[27],word[20];
    printf("Enter characters :");
    fgets(ctrs,27,stdin);
    printf("\nEnter word :");

    scanf(" %s", &word);
    for(int i=0; word[i]!='\0';i++)
    {
        found = 0;
        for(int j=0; ctrs[j]!='\0' ;j++)
        {   
            if(ctrs[j]==word[i])
            {  
                found=1; 
                break;
             }
        }
        if(found == 0)
        {
            printf("Cannot be made");
            return 1;
        }
    }
    printf("Can be made");   
    return 0;
}