#include <stdio.h>
int main()
{
    int num,digits[4];
    printf("Enter a number :");
    scanf("%d",&num);
    for(int temp = num,i=0;i<4; temp/=10,i++)
        digits[i]=temp%10;
    
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<4;j++)
        {
            for(int k=0;k<4;k++)
            {
                for(int l=0;l<4;l++)
                    printf("\n%d%d%d%d",digits[i],digits[j],digits[k],digits[l]);
            }
        }
    }
    
    return 0;
}