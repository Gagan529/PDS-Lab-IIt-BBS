#include <stdio.h>
void main()
{
    int sum = 0;    
    //bool c = true;
    while(1)
    {
        int n;
        printf("Enter Input :");
        scanf("%d", &n);
        char c;
        printf("Enter Y for Yes and N for No :");
        scanf(" %c", &c);
        
        if(c== 'Y' || c== 'y')
        {
            if(n%2 == 0)
            sum = sum+n;
            else
            continue;
        }
        else if(c == 'N' || c == 'n')
        {
            if(n%2 == 0)
            sum = sum + n;
            printf("Sum = %d", sum);
            break;
        }
        else{
            printf("Wrong Input");
        }
    }
}