#include<stdio.h>
union arrays
{
    int nums[100];
    float decimals[100];
    char alphas[100];
};

int main()
{
    int size;
    printf("Enter size of arrays:");
    scanf("%d",&size);
    union arrays arr;
    int in[size];
    float fl[size];
    char ch[size];
    for(int x=0;x<size;x++)
    {
        printf("Enter element of integer array:");
        scanf("%d",&arr.nums[x]);
        in[x] = arr.nums[x];

        printf("Enter element of float array:");
        scanf("%f",&arr.decimals[x]);
        fl[x]=arr.decimals[x];
        
        printf("Enter element of character array:");
        scanf(" %c",&arr.alphas[x]);
        ch[x]=arr.alphas[x];
    }
    for(int i=0;i<size;i++)
        printf("%d\t",in[i]);
    
    printf("\n");
    for(int i=0;i<size;i++)
        printf("%.2f\t",fl[i]);
    
    printf("\n");
    for(int i=0;i<size;i++)
        printf("%c\t",ch[i]);
    
    
}