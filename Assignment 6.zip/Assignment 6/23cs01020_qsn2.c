#include <stdio.h>

void print(int arr[], int avg,int size)
{
    for(int i=0; i<size ;i++)
    {
        if(arr[i] > avg)
            printf("%d ,",arr[i]);
    }
}
int main()
{
    int size , sum=0 ,avg;
    printf("Enter array size :");
    scanf("%d",&size);
    int arr[size];
    for(int i = 0 ; i < size ; i++ )
    {
        printf("Enter element :");
        scanf("%d",&arr[i]);
        sum+=arr[i];
    }
    avg = sum / size;
    print(arr , avg ,size);
}