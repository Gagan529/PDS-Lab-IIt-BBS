#include <string.h>
#include <stdio.h>

int chk_sub(char str[30],char sub[30])
{
    int found;
    for(int i=0;i<strlen(str);i++)
    {
        found = 1;
        for(int j=0,k=i;j<strlen(sub);j++,k++)
        {
            if(str[k] != sub[j])
            {
                found = 0;
                break;
            }
        }
        if(found == 1)
            return 1;
    }
    return 0;
}
int main()
{
    char str[30],sub[30];
    printf("Enter a string:");
    gets(str);
    printf("Enter string to be searched:");
    gets(sub);
    if(chk_sub(str,sub))
        printf("Is a substring");
    else      
        printf("Not substring");
    return 0;
}