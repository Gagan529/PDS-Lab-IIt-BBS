#include <stdio.h>

int n;
void check(int (*ptr)[n+1])
{
    int found;
    for(int i=0;i< n+1;i++)
    {
        found = 0;
        for(int j=i+1;j<n+1;j++) 
        {
            if(*(*ptr+i) == 0)
                break;
            if((*(*ptr+i) ^ *(*ptr+j)) == 0)
            {
                found = 1;
                *(*ptr+j) = 0;
            }
        }
        if(found)
            printf("%d,",*(*ptr+i));
    }
}
int main()
{
    printf("Enter value of 'N' :");
    scanf("%d",&n);
    int arr[n+1];
    int (*ptr)[n+1] = &arr;
    for(int i=0;i<n+1;i++)
    {
        printf("Enter element :");
        scanf("%d",&arr[i]);
        if(arr[i] > n)
        {
            printf("Invalid integer entered !");
            return 1;
        }
    }
    check(ptr);
}