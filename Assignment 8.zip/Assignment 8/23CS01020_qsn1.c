#include <stdio.h>
void circular_shift(int *x,int *y,int *z)
{
    int temp;
    temp = *x;
    *x = *y;
    *y = *z;
    *z = temp;
}
int main()
{
    int x,y,z;
    printf("Enter three numbers (x,y,z) :");
    scanf("%d%d%d",&x,&y,&z);
    printf("Values (x,y,z) before shift:%d\t%d\t%d\n",x,y,z);
    circular_shift(&x,&y,&z);
    printf("Values (x,y,z) after shift :%d\t%d\t%d",x,y,z);
    return 0;
}