#include<stdio.h>
int main(){
    int x;
    float y;
    char z;

    printf("adders of x:- %p\n", &x);
    printf("adders of y:- %p\n", &y);
    printf("adders of z:- %p\n", &z);
    return 0;

}