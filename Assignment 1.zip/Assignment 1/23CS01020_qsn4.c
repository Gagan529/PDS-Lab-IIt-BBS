#include <stdio.h>

int main(){
    double e = 2.718281828;
    printf("%.f\n", e);
    printf("%1.f.\n", e);
    printf("%.1f\n", e);
    printf("%.2f\n", e);
    printf("%.6f\n", e);
    printf("%.6f\n", e);
    printf("%.7f\n", e);
    return 0;
}