#include<stdio.h>
int main(){
    printf("Gagan Gupta\n23CS01020\nComputer science");
    return 0;
}