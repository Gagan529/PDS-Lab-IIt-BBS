#include<stdio.h>
int main()
{
    int x;
    printf("Enter a number :");
    scanf("%d",&x);
    if( x & 1 == 1)
    {
        printf("Odd Number");
    }
    else
        printf("Even number");
    return 0;
}