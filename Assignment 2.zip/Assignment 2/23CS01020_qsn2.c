#include<stdio.h>
int main()
{
    int x,y,z;
    printf("\nEnter three numbers :");
    scanf("%d%d%d",&x,&y,&z);
    int max = x > y ? ( x > z ? x : z ) : ( y > z ? y : z );
    printf("\nMax number is :%d",max);
    return 0;
}