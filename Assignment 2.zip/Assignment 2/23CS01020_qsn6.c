#include<stdio.h>
int main()
{
    int x;
    printf("Enter a number :");
    scanf("%d",&x);
    if( x>100 && x<200 && x%2!=0)
        printf("True");
    else
        printf("False");
    return 0;
}