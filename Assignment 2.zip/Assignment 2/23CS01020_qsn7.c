#include<stdio.h>
#include<math.h>

int main()
{
    float meal_cost , tax, tip ;
    printf("Meal Cost :");
    scanf("%f",&meal_cost);
    printf("Tip percentage :");
    scanf("%f",&tax);
    printf("Tax percentage :");
    scanf("%f",&tip);
    int total = (int)(round(meal_cost + tax*0.01*meal_cost + tip*0.01*meal_cost));
    printf("Total : %d",total);
    return 0;
}