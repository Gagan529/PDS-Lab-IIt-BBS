#include<stdio.h>
int main()
{
    int days;
    printf("\nEnter total number of days :");
    scanf("%d",&days);
    if( days >= 365)
    {
        printf("Years : %d",days/365 );
        days%=365;
    }
    if(days >= 30)
    {
        printf("\nMonths : %d", days/30);
        days%=30;
    }
    if( days >=7 )
    {
        printf("\nWeeks : %d", days/7);
        days%=7;
    }
    if( days > 0 )
    {
        printf("\nDays : %d", days);
    }
    return 0;
}