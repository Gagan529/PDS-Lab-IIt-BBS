#include <stdio.h>

int main() {
    int number;

    // Input number from user
    printf("Enter an integer: ");
    scanf("%d", &number);

    // Using switch case to determine even or odd
    switch (number % 2) {
        case 0:
            printf("%d is an even number.\n", number);
            break;
        case 1:
        case -1: // This case is for negative numbers
            printf("%d is an odd number.\n", number);
            break;
    }

    return 0;
}