#include <stdio.h>

int main() {
    int creditScore;
    float balance, interestRate;

    // Input credit score and current balance
    printf("Enter your credit score: ");
    scanf("%d", &creditScore);

    printf("Enter your current balance: ");
    scanf("%f", &balance);

    // Determine interest rate based on credit score
    if (creditScore < 600) {
        interestRate = 0.15;  // 15% interest rate for scores below 600
    } else if (creditScore >= 600 && creditScore <= 750) {
        interestRate = 0.12;  // 12% interest rate for scores between 600 and 750
    } else {
        interestRate = 0.10;  // 10% interest rate for scores above 750
    }

    // Calculate interest
    float interest = balance * interestRate;

    // Output calculated interest
    printf("Interest on your balance: $%.2f\n", interest);

    return 0;
}